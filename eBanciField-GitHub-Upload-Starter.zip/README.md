# eBanci Field — Android starter

This repository starter builds a **demo/debug APK** using GitHub Actions.

## Build
1. Upload the project files to the repository's `main` branch, preserving folder paths.
2. GitHub Actions starts automatically after the workflow file is uploaded.
3. Open the **Actions** tab, choose **Build Android APK**, then download the `eBanciField-debug-apk` artifact from a successful run.

## Important
This is only a build-pipeline starter. It is **not** the complete census app. Camera capture, GPS, Room offline database, authentication, encryption, survey forms, Supabase sync, review workflow, and admin dashboard still need implementation and testing. Do not enter real personal or health data into this demo.
