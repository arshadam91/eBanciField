package my.ebancifield

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { FieldHome() } }
    }
}

@Composable
fun FieldHome() {
    var project by remember { mutableStateOf("eBanci Field") }
    var note by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Belum ada rumah dibuka") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(project, style = MaterialTheme.typography.headlineMedium)
        Text("Prototaip Android awal • mod luar talian")
        HorizontalDivider()
        Text("Aliran kerja bancian", style = MaterialTheme.typography.titleLarge)
        Text("1. Ambil foto rumah dan cipta ID")
        Text("2. Pilih Berpenghuni / Rumah tutup / Lawatan semula")
        Text("3. Lengkapkan maklumat isi rumah dan individu")
        Text("4. Tutup rekod sebelum tangkap rumah seterusnya")
        OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Catatan ringkas (pilihan)") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { status = "Rekod contoh disediakan — fungsi simpan, kamera dan GPS belum dibina." }, modifier = Modifier.fillMaxWidth()) { Text("Buka rekod rumah (demo)") }
        Text(status, style = MaterialTheme.typography.bodyMedium)
        Text("Nota: Ini APK starter untuk menguji proses binaan sahaja, bukan aplikasi bancian lengkap.")
    }
}
