# eBanci Field v1.0 – Modul Rekod Rumah

APK Android awal yang boleh diuji:
- Ambil foto rumah menggunakan kamera (imej disimpan dalam storan dalaman aplikasi).
- Cipta ID rumah automatik mengikut format EBF-T01-000001.
- Rekod masa, GPS terakhir diketahui dan ketepatan lokasi (minta kebenaran Android).
- Status Berpenghuni / Rumah tutup / Lawatan semula / Kosong.
- Maklumat asas ketua isi rumah, alamat, telefon pilihan, bilangan ahli dan catatan.
- SQLite tempatan; satu rekod aktif pada satu masa dan rekod perlu ditutup sebelum rumah seterusnya.
- Senarai rekod tersimpan.

Had versi ini:
- GPS menggunakan lokasi terakhir diketahui; hidupkan Location/GPS dan tekan Dapatkan GPS.
- Foto kamera disimpan dalam storan dalaman aplikasi.
- Belum ada borang individu terperinci, login pasukan, penyegerakan Supabase, dashboard admin, enkripsi pangkalan data atau eksport.
- House ID berturutan untuk satu pemasangan/peranti sahaja; belum diagihkan oleh server.

Build:
GitHub Actions workflow boleh digunakan selepas fail projek diekstrak ke root.
