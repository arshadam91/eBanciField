package my.ebancifield

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class House(
    val id: String, val photo: String, val lat: String, val lon: String,
    val accuracy: String, val capturedAt: String, val status: String,
    val head: String, val address: String, val phone: String,
    val members: String, val notes: String, val closed: Boolean
)

class HouseDb(context: Context) : SQLiteOpenHelper(context, "ebanci_local.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE houses(
            id TEXT PRIMARY KEY, photo TEXT, lat TEXT, lon TEXT, accuracy TEXT,
            captured_at TEXT, status TEXT, head TEXT, address TEXT, phone TEXT,
            members TEXT, notes TEXT, closed INTEGER)""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun save(h: House) {
        val v = ContentValues().apply {
            put("id", h.id); put("photo", h.photo); put("lat", h.lat); put("lon", h.lon)
            put("accuracy", h.accuracy); put("captured_at", h.capturedAt); put("status", h.status)
            put("head", h.head); put("address", h.address); put("phone", h.phone)
            put("members", h.members); put("notes", h.notes); put("closed", if (h.closed) 1 else 0)
        }
        writableDatabase.insertWithOnConflict("houses", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun all(): List<House> {
        val result = mutableListOf<House>()
        readableDatabase.rawQuery("SELECT * FROM houses ORDER BY captured_at DESC", null).use { c ->
            while (c.moveToNext()) result.add(House(
                c.getString(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4),
                c.getString(5), c.getString(6), c.getString(7), c.getString(8), c.getString(9),
                c.getString(10), c.getString(11), c.getInt(12) == 1
            ))
        }
        return result
    }
}

class MainActivity : ComponentActivity() {
    private lateinit var db: HouseDb
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = HouseDb(this)
        setContent { MaterialTheme { CensusScreen(this, db) } }
    }
}

@Composable
fun CensusScreen(context: Context, db: HouseDb) {
    val prefs = context.getSharedPreferences("ebanci", Context.MODE_PRIVATE)
    var active by remember { mutableStateOf(db.all().firstOrNull { !it.closed }) }
    var records by remember { mutableStateOf(db.all()) }
    var photoPath by remember { mutableStateOf(active?.photo ?: "") }
    var lat by remember { mutableStateOf(active?.lat ?: "") }
    var lon by remember { mutableStateOf(active?.lon ?: "") }
    var accuracy by remember { mutableStateOf(active?.accuracy ?: "") }
    var status by remember { mutableStateOf(active?.status ?: "Berpenghuni") }
    var head by remember { mutableStateOf(active?.head ?: "") }
    var address by remember { mutableStateOf(active?.address ?: "") }
    var phone by remember { mutableStateOf(active?.phone ?: "") }
    var members by remember { mutableStateOf(active?.members ?: "1") }
    var notes by remember { mutableStateOf(active?.notes ?: "") }
    var message by remember { mutableStateOf("Sedia. Ambil foto rumah untuk bermula.") }

    fun refresh() { records = db.all(); active = records.firstOrNull { !it.closed } }
    fun currentId(): String {
        val n = prefs.getInt("counter", 0) + 1
        prefs.edit().putInt("counter", n).apply()
        return "EBF-T01-" + n.toString().padStart(6, '0')
    }
    fun persist(closed: Boolean) {
        val h = active ?: return
        db.save(h.copy(lat=lat, lon=lon, accuracy=accuracy, status=status, head=head,
            address=address, phone=phone, members=members, notes=notes, closed=closed))
        refresh()
    }

    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap: Bitmap? ->
        if (bitmap != null) {
            val dir = File(context.filesDir, "house_photos").apply { mkdirs() }
            val file = File(dir, "${active?.id ?: "new_house"}.jpg")
            FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            photoPath = file.absolutePath
            if (active == null) {
                val id = currentId()
                val now = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
                active = House(id, photoPath, "", "", "", now, "Belum dipilih", "", "", "", "1", "", false)
            }
            active?.let { db.save(it.copy(photo=photoPath)) }
            refresh()
            message = "Foto disimpan. Rekod ${active?.id ?: records.firstOrNull()?.id} dibuka."
        } else message = "Kamera dibatalkan. Cuba sekali lagi."
    }

    fun getLocation() {
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        try {
            val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            val loc: Location? = providers.firstNotNullOfOrNull { p ->
                if (lm.isProviderEnabled(p)) lm.getLastKnownLocation(p) else null
            }
            if (loc != null) {
                lat = loc.latitude.toString(); lon = loc.longitude.toString()
                accuracy = loc.accuracy.toString()
                message = "GPS direkod (ketepatan ±${loc.accuracy.toInt()} m)."
                active?.let { db.save(it.copy(lat=lat, lon=lon, accuracy=accuracy)) }
            } else message = "Lokasi belum tersedia. Aktifkan GPS dan cuba lagi di kawasan terbuka."
        } catch (_: SecurityException) { message = "Kebenaran lokasi belum diberi." }
    }

    val locationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result[Manifest.permission.ACCESS_FINE_LOCATION] == true || result[Manifest.permission.ACCESS_COARSE_LOCATION] == true) getLocation()
        else message = "Kebenaran lokasi ditolak. GPS tidak direkod."
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("eBanci Field", style = MaterialTheme.typography.headlineMedium)
        Text("Versi 1.0 • Rekod rumah luar talian")
        HorizontalDivider()
        Text("ALIRAN REKOD", style = MaterialTheme.typography.titleMedium)
        Text("1. Ambil foto rumah  2. Rekod GPS  3. Pilih status  4. Lengkapkan maklumat  5. Tutup rekod")
        if (active == null) {
            Button(onClick = { camera.launch(null) }, modifier = Modifier.fillMaxWidth()) { Text("📷 Ambil foto rumah & cipta ID") }
        } else {
            Text("Rekod aktif: ${active!!.id}", style = MaterialTheme.typography.titleMedium)
            Text("Foto: ${if (photoPath.isNotBlank()) "Disimpan" else "Belum ada"}")
            Button(onClick = { camera.launch(null) }, modifier = Modifier.fillMaxWidth()) { Text("Ambil / ganti foto rumah") }
            OutlinedButton(onClick = {
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) getLocation()
                else locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            }, modifier = Modifier.fillMaxWidth()) { Text("Dapatkan GPS & ketepatan") }
            Text("GPS: ${if (lat.isBlank()) "Belum direkod" else "$lat, $lon (±$accuracy m)"}")
            Text("Status rumah", style = MaterialTheme.typography.titleMedium)
            listOf("Berpenghuni", "Rumah tutup", "Lawatan semula", "Kosong") .forEach { s ->
                Row {
                    RadioButton(selected = status == s, onClick = { status = s; active?.let { db.save(it.copy(status=s)) } })
                    Text(s, modifier = Modifier.padding(top=12.dp))
                }
            }
            if (status == "Berpenghuni") {
                OutlinedTextField(head, { head=it }, label={Text("Nama ketua isi rumah *")}, modifier=Modifier.fillMaxWidth())
                OutlinedTextField(address, { address=it }, label={Text("Alamat rumah")}, modifier=Modifier.fillMaxWidth())
                OutlinedTextField(phone, { phone=it }, label={Text("No. telefon (pilihan)")}, modifier=Modifier.fillMaxWidth())
                OutlinedTextField(members, { members=it.filter(Char::isDigit) }, label={Text("Bilangan ahli isi rumah *")}, modifier=Modifier.fillMaxWidth())
                Text("Versi seterusnya akan tambah borang terperinci setiap individu.")
            }
            OutlinedTextField(notes, { notes=it }, label={Text("Catatan (pilihan)")}, modifier=Modifier.fillMaxWidth(), minLines=2)
            Button(onClick = {
                if (status == "Berpenghuni" && (head.isBlank() || (members.toIntOrNull() ?: 0) < 1)) {
                    message = "Isi nama ketua isi rumah dan bilangan ahli (sekurang-kurangnya 1)."
                } else {
                    persist(true)
                    photoPath=""; lat=""; lon=""; accuracy=""; status="Berpenghuni"; head=""; address=""; phone=""; members="1"; notes=""
                    message="Rekod ditutup. Sekarang boleh ambil rumah seterusnya."
                }
            }, modifier=Modifier.fillMaxWidth()) { Text("TUTUP REKOD RUMAH") }
        }
        Text(message, color=MaterialTheme.colorScheme.primary)
        HorizontalDivider()
        Text("Rekod tersimpan: ${records.size}", style=MaterialTheme.typography.titleMedium)
        records.take(10).forEach { h ->
            Text("${h.id} • ${h.status} • ${if(h.closed) "Ditutup" else "Aktif"}")
        }
        Text("Data disimpan dalam storan tempatan telefon. Sambungan cloud dan borang individu terperinci belum dimasukkan.", style=MaterialTheme.typography.bodySmall)
    }
}
